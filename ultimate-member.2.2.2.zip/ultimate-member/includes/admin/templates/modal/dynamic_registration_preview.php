<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>


<div id="UM_preview_registration" style="display:none">

	<div class="um-admin-modal-head">
		<h3><?php _e( 'Review Registration Details', 'ultimate-member' ); ?></h3>
	</div>

	<div class="um-admin-modal-body"></div>

	<div class="um-admin-modal-foot"></div>

</div>